package lesson8.lecture.functionalinterfaceannotation;

@FunctionalInterface
public interface Example2 {
	String toString();
	int act(int x);
	
}


