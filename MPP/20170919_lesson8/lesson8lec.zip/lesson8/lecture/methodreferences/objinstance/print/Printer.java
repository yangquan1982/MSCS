package lesson8.lecture.methodreferences.objinstance.print;

public class Printer {
	public void print(Object ob) {
		System.out.println(ob.toString());
	}
}
