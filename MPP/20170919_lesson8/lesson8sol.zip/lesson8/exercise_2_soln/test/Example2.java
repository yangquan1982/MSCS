package lesson8.exercise_2_soln.test;

@FunctionalInterface
public interface Example2 {
	public String toString();
	public void act();
}
