package lesson8.exercise_2;

public class MyRandGen implements MyIface {

}
