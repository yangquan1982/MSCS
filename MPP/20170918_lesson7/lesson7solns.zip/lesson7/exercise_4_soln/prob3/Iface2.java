package lesson7.exercise_4_soln.prob3;

public interface Iface2 {
	static int myMethod(int x) {
		return x + 1;
	}
}


