package lesson4.lecture.staticinherit.first;

public class Super {
	static void print() {
		System.out.println("hello");
	}	
}
