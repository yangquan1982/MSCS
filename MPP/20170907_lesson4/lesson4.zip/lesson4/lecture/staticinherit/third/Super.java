package lesson4.lecture.staticinherit.third;

public class Super {
	
	static void tryit() {
		System.out.println("trying it");
	}
}
