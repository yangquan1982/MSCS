package lesson4.labs.prob4E;

public abstract class Account {
	public String getAccountID() {
		return "";
	}

	public double getBalance() {
		return 0.0;
	}

	public double computeUpdatedBalance() {
		return 0.0;
	}
}
