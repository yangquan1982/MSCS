drop table CHECKOUTRECORD;
drop table LIBRARYMEMBER;
drop table PubCopy;
drop table PUBLICATIONAUTHOR;
drop table PUBLICATION;
drop table Author;
drop table Address;