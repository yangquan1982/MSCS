truncate table CHECKOUTRECORD ;
truncate table PUBCOPY;
truncate table PUBLICATIONAUTHOR ;
truncate table AUTHOR ;
truncate table PUBLICATION ;
truncate table LIBRARYMEMBER;
truncate table ADDRESS ;
