package lesson3.labs.prob4;

public class Trailer extends Property {

	@Override
	public double computeRent(){
		return 500;
	}
}
