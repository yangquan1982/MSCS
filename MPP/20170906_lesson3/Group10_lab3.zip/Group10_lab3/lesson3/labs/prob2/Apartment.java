/**
 * 
 */
package lesson3.labs.prob2;

/**
 * @author quanyang
 *
 */
public class Apartment {
	int rent;

	/**
	 * @param rent
	 */
	public Apartment(int rent) {
		this.rent = rent;
	}

	/**
	 * @return the rent
	 */
	public int getRent() {
		return rent;
	}

	/**
	 * @param rent the rent to set
	 */
	public void setRent(int rent) {
		this.rent = rent;
	}
	
}
