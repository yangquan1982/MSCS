package lesson3.lecture.polymorphism2;

public class Faculty extends StaffPerson {
	public double computeStipend() {
		return 4000.0;
	}
}
