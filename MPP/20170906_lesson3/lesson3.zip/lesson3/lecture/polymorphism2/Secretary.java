package lesson3.lecture.polymorphism2;

public class Secretary extends StaffPerson {

	@Override
	public double computeStipend() {
		return 2500.0;
	}

}
