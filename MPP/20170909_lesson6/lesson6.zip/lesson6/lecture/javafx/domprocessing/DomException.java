package lesson6.lecture.javafx.domprocessing;
public class DomException extends Exception {
	
	public DomException() {
		super();
	}
	
	public DomException(String s) {
		super(s);
	}

}

