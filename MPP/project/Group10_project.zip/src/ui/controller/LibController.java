package ui.controller;

public interface LibController {

}
