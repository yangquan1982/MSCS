//This is a note from the team responsible for this project.
//It tells the professor about any extra work that was done or other things
//that need to be mentioned.

1. Implemented all the required 4 cases and optional 3 cases
2. Illustrated the project by using use case diagram, class diagram and sequence diagram
3. Apply MVC pattern to UI in most cases, separate the window, show(fxml) and controller
4. Use powerful and well-organized rule engine to verify the input data validity,
   introduce regular expression to verify telephone and isbn
5. Re-organized the user interface and add user logout funciton
