This is the startup code for Lab 4.

This version imitates the situation
in which data is read from a database
where there is a many-many relationship
with a natural association class.

Relationships are created when data is loaded
but new instances of Student/Section cannot be created safely.
The relationships created at startup
permit exepcted navigation.