package lesson11.lecture.generics.toarray;

public class TestList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
