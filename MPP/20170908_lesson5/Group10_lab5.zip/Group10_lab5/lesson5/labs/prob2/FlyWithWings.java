package lesson5.labs.prob2;

public class FlyWithWings implements FlyBehavior {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("fly with wings");
	}

}
