Shows how interfaces can be used for polymorphism.
These files do it the non-OO way.