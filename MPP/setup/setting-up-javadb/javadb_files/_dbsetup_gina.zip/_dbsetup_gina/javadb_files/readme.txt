change the file extension for each file here to "bat" and
it will become a functioning batch file