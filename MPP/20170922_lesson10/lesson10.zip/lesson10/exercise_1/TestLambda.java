package lesson10.exercise_1;

import junit.framework.TestCase;

public class TestLambda extends TestCase {
	public void testLambda() {
		//your test 
	}
}
